import { cn } from "@/lib/utils";

export function BrandMark({ className, light = false }: { className?: string; light?: boolean }) {
  return (
    <svg className={cn("shrink-0", className)} viewBox="0 0 64 72" fill="none" aria-hidden="true">
      <path
        d="M10 8v36l22 18 22-18V8H42v30L32 46 22 38V8H10Z"
        fill={light ? "#ffffff" : "#062c52"}
        opacity={light ? 0.95 : 1}
      />
      <path d="M27 8h10v26l-5 5-5-5V8Z" fill={light ? "#9ec8ff" : "#1676ff"} />
    </svg>
  );
}
