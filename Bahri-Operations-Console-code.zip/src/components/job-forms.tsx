import { useState } from "react";
import { toast } from "sonner";
import { CreateJobForm } from "@/components/create-job-form";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { Textarea } from "@/components/ui/textarea";
import { BOATS, CAPTAINS } from "@/lib/ops/constants";
import { useOps } from "@/lib/ops/store";
import type { BoatId, Job } from "@/lib/ops/types";

export function NewRequestSheet({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent title="Create new job">
        <CreateJobForm onCreated={() => onOpenChange(false)} onClose={() => onOpenChange(false)} />
      </SheetContent>
    </Sheet>
  );
}

export function DispatchSheet({
  job,
  open,
  onOpenChange,
}: {
  job: Job | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const assignAndDispatch = useOps((s) => s.assignAndDispatch);
  const planJob = useOps((s) => s.planJob);
  const dispatchJob = useOps((s) => s.dispatchJob);
  const [boatId, setBoatId] = useState<BoatId>(job?.boatId ?? "yara");
  const [captainId, setCaptainId] = useState(job?.captainId ?? CAPTAINS.find((c) => c.boatId === (job?.boatId ?? "yara"))?.id ?? "");

  if (!job) return null;
  const captains = CAPTAINS.filter((c) => c.boatId === boatId);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent title={`${job.ref} · assign`}>
        <div className="flex flex-col gap-4">
          <div>
            <Label htmlFor="boat">Boat</Label>
            <Select
              id="boat"
              value={boatId}
              onChange={(e) => {
                const id = e.target.value as BoatId;
                setBoatId(id);
                setCaptainId(CAPTAINS.find((c) => c.boatId === id && c.rank === "Master")?.id ?? "");
              }}
            >
              {BOATS.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name} · {b.callsign}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label htmlFor="cap">Captain</Label>
            <Select id="cap" value={captainId} onChange={(e) => setCaptainId(e.target.value)}>
              {captains.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="secondary"
              onClick={() => {
                planJob(job.id, boatId, captainId);
                toast("Planned");
                onOpenChange(false);
              }}
            >
              Plan only
            </Button>
            <Button
              onClick={() => {
                assignAndDispatch(job.id, boatId, captainId);
                toast(`Dispatched to ${boatId === "yara" ? "Yara" : "Jenan"}`);
                onOpenChange(false);
              }}
            >
              Dispatch
            </Button>
          </div>
          {job.boatId && job.state === "planned" ? (
            <Button
              variant="outline"
              onClick={() => {
                dispatchJob(job.id);
                toast("Dispatched");
                onOpenChange(false);
              }}
            >
              Send as planned
            </Button>
          ) : null}
        </div>
      </SheetContent>
    </Sheet>
  );
}

export function VerifySheet({
  job,
  open,
  onOpenChange,
}: {
  job: Job | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const verifyJob = useOps((s) => s.verifyJob);
  const [notes, setNotes] = useState("Stamps complete. Trip counted.");

  if (!job) return null;
  const complete = ["departed_base", "alongside", "ops_start", "ops_complete", "departed_vessel", "returned_base"].every(
    (k) => job.timestamps[k as keyof typeof job.timestamps],
  );

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent title={`Verify ${job.ref}`}>
        <p className="mb-4 text-sm text-muted">
          {complete
            ? "All six device stamps are present. Close the trip into the daily report."
            : "Cannot close — missing stamps. Crew must finish the log."}
        </p>
        <Label htmlFor="vn">Verify notes</Label>
        <Textarea id="vn" value={notes} onChange={(e) => setNotes(e.target.value)} />
        <Button
          className="mt-4 w-full"
          size="lg"
          disabled={!complete}
          onClick={() => {
            verifyJob(job.id, notes);
            toast("Trip closed · counted");
            onOpenChange(false);
          }}
        >
          Close and count
        </Button>
      </SheetContent>
    </Sheet>
  );
}
