import { Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { boardStatus, boatName, formatClock, formatDateShort, JOB_TYPE_LABEL, jobWhen } from "@/lib/ops/format";
import type { Job, Vessel } from "@/lib/ops/types";
import { cn } from "@/lib/utils";

export function JobRow({ job, vessel, highlight }: { job: Job; vessel?: Vessel; highlight?: boolean }) {
  const status = boardStatus(job);
  const when = jobWhen(job);
  return (
    <Link
      to="/jobs/$jobId"
      params={{ jobId: job.id }}
      className={cn(
        "grid grid-cols-[4.5rem_1fr_1.25rem] items-center gap-3 rounded-md border border-border bg-surface px-3 py-3 transition-colors hover:border-primary/40",
        highlight && "border-primary/40 bg-info-soft/60",
      )}
    >
      <div>
        <div className="text-[15px] font-bold tabular-nums tracking-tight">{formatClock(when)}</div>
        <div className="mt-0.5 text-[11px] text-muted">{formatDateShort(when)}</div>
      </div>
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-1.5">
          <strong className="text-sm font-semibold">{job.boatId ? boatName(job.boatId) : "Unassigned"}</strong>
          <Badge tone={status.tone}>{status.label}</Badge>
        </div>
        <p className="mt-0.5 truncate text-xs text-muted">
          {JOB_TYPE_LABEL[job.type]}
          {" · "}
          {vessel?.name ?? job.vesselId}
        </p>
        <p className="truncate text-xs text-subtle">
          {job.pax != null ? `${job.pax} pax` : job.cargoPallets ? `${job.cargoPallets} pallets` : "—"}
        </p>
      </div>
      <ChevronRight className="size-5 text-subtle" />
    </Link>
  );
}
