import { useMemo } from "react";
import { useNow } from "@/components/clock";
import { PLOT_BOUNDS } from "@/lib/ops/constants";
import { boatPose, project } from "@/lib/ops/geo";
import { activeJobFor } from "@/lib/ops/store";
import type { BoatId, Job, Vessel } from "@/lib/ops/types";
import { cn } from "@/lib/utils";

const W = 1000;
const H = 720;

function landPath() {
  const pts = [
    [50.08, 26.78],
    [50.155, 26.78],
    [50.162, 26.74],
    [50.148, 26.7],
    [50.158, 26.66],
    [50.172, 26.642],
    [50.165, 26.62],
    [50.14, 26.58],
    [50.12, 26.52],
    [50.08, 26.52],
  ];
  return pts
    .map(([lng, lat], i) => {
      const p = project(lat, lng, W, H);
      return `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`;
    })
    .join(" ")
    .concat(" Z");
}

export function OpsPlot({
  vessels,
  jobs,
  highlightBoat,
  className,
}: {
  vessels: Vessel[];
  jobs: Job[];
  highlightBoat?: BoatId;
  className?: string;
}) {
  const now = useNow(1000);
  const yaraJob = activeJobFor(jobs, "yara");
  const jenanJob = activeJobFor(jobs, "jenan");
  const yaraV = vessels.find((v) => v.id === yaraJob?.vesselId);
  const jenanV = vessels.find((v) => v.id === jenanJob?.vesselId);
  const yara = boatPose("yara", yaraJob, yaraV, now);
  const jenan = boatPose("jenan", jenanJob, jenanV, now);

  const rings = useMemo(() => {
    const origin = project(26.6412, 50.1618, W, H);
    return [80, 160, 240, 320].map((r) => ({ ...origin, r }));
  }, []);

  return (
    <div className={cn("relative overflow-hidden rounded-xl border border-border bg-sea", className)}>
      <svg viewBox={`0 0 ${W} ${H}`} className="h-full w-full" role="img" aria-label="Ras Tanura operations plot">
        <rect width={W} height={H} fill="var(--color-sea)" />
        {rings.map((r) => (
          <circle
            key={r.r}
            cx={r.x}
            cy={r.y}
            r={r.r}
            fill="none"
            stroke="var(--color-track)"
            strokeWidth="1"
            opacity="0.45"
          />
        ))}
        <path d={landPath()} fill="var(--color-land)" stroke="var(--color-border-strong)" strokeWidth="1.2" />
        {gridLines()}
        {vessels.map((v) => {
          const p = project(v.lat, v.lng, W, H);
          const active = v.id === yaraJob?.vesselId || v.id === jenanJob?.vesselId;
          return (
            <g key={v.id} transform={`translate(${p.x},${p.y})`}>
              <rect
                x="-7"
                y="-3.5"
                width="14"
                height="7"
                rx="1"
                fill={active ? "var(--color-primary)" : "var(--color-track)"}
                opacity={active ? 1 : 0.85}
              />
              <text x="10" y="3" fill="var(--color-muted)" fontSize="12" fontFamily="Plus Jakarta Sans, sans-serif">
                {v.berth}
              </text>
            </g>
          );
        })}
        {boatMark("Y", yara, highlightBoat === "yara")}
        {boatMark("J", jenan, highlightBoat === "jenan")}
        {baseMark()}
      </svg>
      <div className="pointer-events-none absolute left-3 top-3 rounded-md border border-border bg-bg/80 px-2 py-1 font-mono text-xs uppercase tracking-wider text-muted">
        Ras Tanura · {PLOT_BOUNDS.north.toFixed(2)}N {PLOT_BOUNDS.east.toFixed(2)}E
      </div>
      <div className="pointer-events-none absolute bottom-3 left-3 flex gap-3 font-mono text-xs uppercase tracking-wider text-muted">
        <span className="flex items-center gap-1.5">
          <span className="inline-block size-2 rounded-sm bg-primary" /> OSV
        </span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block h-1.5 w-3 bg-track" /> Anchored
        </span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block size-2 bg-land" /> Shore
        </span>
      </div>
    </div>
  );
}

function gridLines() {
  const lines = [];
  for (let i = 1; i < 8; i++) {
    const x = (W / 8) * i;
    const y = (H / 6) * i;
    lines.push(
      <line key={`v${i}`} x1={x} y1={0} x2={x} y2={H} stroke="var(--color-track)" strokeWidth="0.6" opacity="0.25" />,
    );
    if (i < 6) {
      lines.push(
        <line key={`h${i}`} x1={0} y1={y} x2={W} y2={y} stroke="var(--color-track)" strokeWidth="0.6" opacity="0.25" />,
      );
    }
  }
  return <g>{lines}</g>;
}

function boatMark(letter: string, pose: { lat: number; lng: number; heading: number }, hot: boolean) {
  const p = project(pose.lat, pose.lng, W, H);
  return (
    <g key={letter} transform={`translate(${p.x},${p.y})`}>
      <g transform={`rotate(${pose.heading})`}>
        <polygon
          points="0,-12 8,10 -8,10"
          fill={hot ? "var(--color-primary)" : "var(--color-navy)"}
          stroke="var(--color-surface)"
          strokeWidth="1.5"
        />
      </g>
      <text y="22" textAnchor="middle" fill="var(--color-navy)" fontSize="12" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="700">
        {letter}
      </text>
    </g>
  );
}

function baseMark() {
  const p = project(26.6412, 50.1618, W, H);
  return (
    <g transform={`translate(${p.x},${p.y})`}>
      <circle r="4" fill="var(--color-primary)" />
      <text x="8" y="4" fill="var(--color-navy)" fontSize="12" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="700">
        RT base
      </text>
    </g>
  );
}
