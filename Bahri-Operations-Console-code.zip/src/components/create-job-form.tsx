import { Briefcase, Package, Ship, Users } from "lucide-react";
import { type ReactNode, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { BOATS, CAPTAINS } from "@/lib/ops/constants";
import { BOAT_STATUS_LABEL, formatClock, JOB_TYPE_LABEL } from "@/lib/ops/format";
import { activeJobFor, boatStatus, useOps } from "@/lib/ops/store";
import type { BoatId, JobType } from "@/lib/ops/types";
import { cn } from "@/lib/utils";

const TYPES = Object.keys(JOB_TYPE_LABEL) as JobType[];

export function CreateJobForm({ onCreated }: { onCreated?: () => void; onClose?: () => void }) {
  const vessels = useOps((s) => s.vessels);
  const jobs = useOps((s) => s.jobs);
  const createRequest = useOps((s) => s.createRequest);

  const [query, setQuery] = useState("");
  const [vesselId, setVesselId] = useState("");
  const [type, setType] = useState<JobType | "">("");
  const [date, setDate] = useState("2026-08-31");
  const [time, setTime] = useState("17:15");
  const [paxOut, setPaxOut] = useState("");
  const [paxReturn, setPaxReturn] = useState("");
  const [pallets, setPallets] = useState("");
  const [weight, setWeight] = useState("");
  const [cargo, setCargo] = useState("");
  const [boatId, setBoatId] = useState<BoatId | "">("");
  const [captainId, setCaptainId] = useState("");

  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return vessels;
    return vessels.filter((v) => {
      const hay = `${v.name} ${v.imo} ${v.berth}`.toLowerCase();
      return q.split(/[·,]/).every((part) => {
        const p = part.trim();
        return !p || hay.includes(p);
      });
    });
  }, [query, vessels]);

  const captains = CAPTAINS.filter((c) => (boatId ? c.boatId === boatId : true));
  const ready = Boolean(vesselId && type && date && time && boatId && captainId);

  return (
    <form
      className="flex flex-col gap-3"
      onSubmit={(e) => {
        e.preventDefault();
        if (!ready || !type || !boatId) return;
        const scheduledAt = new Date(`${date}T${time}:00+03:00`).toISOString();
        const notes = cargo.trim();
        createRequest({
          vesselId,
          type,
          notes,
          paxOut: paxOut ? Number(paxOut) : undefined,
          paxReturn: paxReturn ? Number(paxReturn) : undefined,
          cargoPallets: pallets ? Number(pallets) : undefined,
          cargoWeightKg: weight ? Number(weight) : undefined,
          requestedBy: "RT ops",
          scheduledAt,
          boatId,
          captainId,
          dispatch: true,
        });
        toast("Job created and dispatched");
        onCreated?.();
        setQuery("");
        setVesselId("");
        setType("");
        setPaxOut("");
        setPaxReturn("");
        setPallets("");
        setWeight("");
        setCargo("");
        setBoatId("");
        setCaptainId("");
      }}
    >
      <Section icon={Briefcase} title="Job">
        <Field label="Mother vessel" required>
          <Input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setVesselId("");
            }}
            placeholder="Search vessel name or IMO"
            list="vessel-options"
          />
          <datalist id="vessel-options">
            {matches.map((v) => (
              <option key={v.id} value={`${v.name} · ${v.imo}`} />
            ))}
          </datalist>
          <Select
            value={vesselId}
            onChange={(e) => {
              setVesselId(e.target.value);
              const v = vessels.find((x) => x.id === e.target.value);
              if (v) setQuery(`${v.name} · ${v.imo}`);
            }}
          >
            <option value="">Select from list</option>
            {matches.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name} · {v.berth} · IMO {v.imo}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Service type" required>
          <Select value={type} onChange={(e) => setType(e.target.value as JobType)}>
            <option value="">Select service type</option>
            {TYPES.map((t) => (
              <option key={t} value={t}>
                {JOB_TYPE_LABEL[t]}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Scheduled date & time" required>
          <div className="grid grid-cols-2 gap-2">
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} />
          </div>
        </Field>
      </Section>

      <Section icon={Users} title="People">
        <div className="grid grid-cols-2 gap-2">
          <Field label="Going out">
            <Input inputMode="numeric" placeholder="e.g. 8" value={paxOut} onChange={(e) => setPaxOut(e.target.value)} />
          </Field>
          <Field label="Returning">
            <Input
              inputMode="numeric"
              placeholder="e.g. 8"
              value={paxReturn}
              onChange={(e) => setPaxReturn(e.target.value)}
            />
          </Field>
        </div>
      </Section>

      <Section icon={Package} title="Cargo">
        <div className="grid grid-cols-2 gap-2">
          <Field label="Pallets planned">
            <Input inputMode="numeric" placeholder="e.g. 10" value={pallets} onChange={(e) => setPallets(e.target.value)} />
          </Field>
          <Field label="Cargo weight (kg)">
            <Input inputMode="numeric" placeholder="e.g. 450" value={weight} onChange={(e) => setWeight(e.target.value)} />
          </Field>
        </div>
        <Field label="Cargo description">
          <Input placeholder="e.g. Spare parts, provisions, tools..." value={cargo} onChange={(e) => setCargo(e.target.value)} />
        </Field>
      </Section>

      <Section icon={Ship} title="Assignment">
        <Field label="Boat" required>
          <div className="grid grid-cols-2 gap-2">
            {BOATS.map((b) => {
              const status = boatStatus(jobs, b.id);
              const live = activeJobFor(jobs, b.id);
              const selected = boatId === b.id;
              return (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => {
                    setBoatId(b.id);
                    const cap = CAPTAINS.find((c) => c.boatId === b.id && c.rank === "Master");
                    if (cap) setCaptainId(cap.id);
                  }}
                  className={cn(
                    "rounded-md border px-3 py-3 text-left transition-colors",
                    selected ? "border-primary bg-info-soft" : "border-border bg-surface hover:border-primary/40",
                  )}
                >
                  <p className="text-sm font-semibold">{b.name}</p>
                  <p
                    className={cn(
                      "mt-1 text-xs font-semibold",
                      status === "at_base" && !live ? "text-ok" : "text-warn",
                    )}
                  >
                    {live && status === "at_base" ? "Assigned" : BOAT_STATUS_LABEL[status]}
                  </p>
                  <p className="mt-2 text-[11px] text-muted">
                    {live ? `On job · ${formatClock(live.scheduledAt ?? live.requestedAt)}` : "Next job — free"}
                  </p>
                </button>
              );
            })}
          </div>
        </Field>
        <Field label="Captain" required>
          <Select value={captainId} onChange={(e) => setCaptainId(e.target.value)}>
            <option value="">Choose captain</option>
            {captains.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} · {c.rank}
              </option>
            ))}
          </Select>
        </Field>
      </Section>

      <Button type="submit" size="lg" className="w-full" disabled={!ready}>
        Create job
      </Button>
      <p className="text-center text-xs text-muted">
        Complete required fields <span className="text-danger">*</span> to create the job.
      </p>
    </form>
  );
}

function Section({
  icon: Icon,
  title,
  children,
}: {
  icon: typeof Briefcase;
  title: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded-md border border-border p-3">
      <div className="mb-3 flex items-center gap-2 text-sm font-semibold">
        <Icon className="size-4 text-muted" />
        {title}
      </div>
      <div className="flex flex-col gap-3">{children}</div>
    </section>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: ReactNode }) {
  return (
    <div>
      <Label className="mb-1.5 normal-case tracking-normal">
        {label}
        {required ? <span className="ml-0.5 text-danger">*</span> : null}
      </Label>
      {children}
    </div>
  );
}
