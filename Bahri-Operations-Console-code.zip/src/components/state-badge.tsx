import { Badge } from "@/components/ui/badge";
import { BOAT_STATUS_LABEL, boardStatus, JOB_TYPE_LABEL } from "@/lib/ops/format";
import type { BoatStatus, Job, JobType } from "@/lib/ops/types";

export function StateBadge({ state, job }: { state?: Job["state"]; job?: Job }) {
  if (job) {
    const s = boardStatus(job);
    return <Badge tone={s.tone}>{s.label}</Badge>;
  }
  const fallback = jobStatusFromState(state);
  return <Badge tone={fallback.tone}>{fallback.label}</Badge>;
}

function jobStatusFromState(state?: Job["state"]) {
  if (state === "reported") return { label: "Completed", tone: "ok" as const };
  if (state === "verifying") return { label: "Returned", tone: "warn" as const };
  if (state === "executing" || state === "tracking") return { label: "Underway", tone: "steel" as const };
  if (state === "dispatched" || state === "planned") return { label: "Assigned", tone: "ok" as const };
  return { label: "Draft", tone: "muted" as const };
}

export function TypeBadge({ type }: { type: JobType }) {
  return <Badge>{JOB_TYPE_LABEL[type]}</Badge>;
}

export function BoatStatusBadge({ status }: { status: BoatStatus }) {
  const tone = status === "at_base" ? "ok" : status === "alongside" ? "ok" : status === "returning" ? "warn" : "steel";
  return <Badge tone={tone}>{BOAT_STATUS_LABEL[status]}</Badge>;
}
