import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium tracking-wide",
  {
    variants: {
      tone: {
        muted: "bg-surface-2 text-muted border border-border",
        steel: "bg-primary/12 text-primary border border-primary/20",
        ok: "bg-ok/15 text-ok-fg border border-ok/25",
        warn: "bg-warn/15 text-warn-fg border border-warn/25",
        danger: "bg-danger/15 text-danger-fg border border-danger/25",
      },
    },
    defaultVariants: { tone: "muted" },
  },
);

export function Badge({
  className,
  tone,
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & VariantProps<typeof badgeVariants>) {
  return <span className={cn(badgeVariants({ tone, className }))} {...props} />;
}
