import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Sheet({
  open,
  onOpenChange,
  children,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  children: ReactNode;
}) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      {children}
    </Dialog.Root>
  );
}

export function SheetContent({
  children,
  className,
  title,
}: {
  children: ReactNode;
  className?: string;
  title: string;
}) {
  return (
    <Dialog.Portal>
      <Dialog.Overlay className="fixed inset-0 z-50 bg-bg/70 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" />
      <Dialog.Content
        className={cn(
          "fixed inset-x-0 bottom-0 z-50 max-h-[92vh] overflow-y-auto rounded-t-xl border border-border bg-surface p-5 shadow-[var(--shadow-panel)]",
          "md:inset-y-0 md:right-0 md:left-auto md:h-full md:w-[420px] md:max-h-none md:rounded-none md:rounded-l-xl",
          "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:slide-out-to-bottom md:data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-bottom md:data-[state=open]:slide-in-from-right",
          className,
        )}
      >
        <div className="mb-4 flex items-center justify-between gap-3">
          <Dialog.Title className="text-base font-medium tracking-tight">{title}</Dialog.Title>
          <Dialog.Close asChild>
            <button
              type="button"
              className="flex size-10 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-fg"
              aria-label="Close"
            >
              <X className="size-4" />
            </button>
          </Dialog.Close>
        </div>
        {children}
      </Dialog.Content>
    </Dialog.Portal>
  );
}
