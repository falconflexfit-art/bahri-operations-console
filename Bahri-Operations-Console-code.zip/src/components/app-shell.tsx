import { Link, useRouterState } from "@tanstack/react-router";
import {
  Bell,
  ChevronDown,
  ClipboardList,
  LayoutGrid,
  RotateCcw,
  Settings,
  Ship,
  Users,
  FileBarChart,
  Wifi,
  WifiOff,
} from "lucide-react";
import { type ReactNode, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { BrandMark } from "@/components/brand-mark";
import { LiveClock } from "@/components/clock";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { BOATS } from "@/lib/ops/constants";
import { boatName } from "@/lib/ops/format";
import { useOps } from "@/lib/ops/store";
import type { Role } from "@/lib/ops/types";

const NAV = [
  { to: "/", label: "Dashboard", icon: LayoutGrid },
  { to: "/jobs", label: "Jobs", icon: ClipboardList },
  { to: "/boats", label: "Boats", icon: Ship },
  { to: "/people", label: "People", icon: Users },
  { to: "/report", label: "Reports", icon: FileBarChart },
  { to: "/admin", label: "Admin", icon: Settings },
] as const;

let didRehydrate = false;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { role, setRole, online, setOnline, resetShift, syncQueue, jobs, vessels } = useOps();
  const [notesOpen, setNotesOpen] = useState(false);

  useEffect(() => {
    if (didRehydrate) return;
    didRehydrate = true;
    void useOps.persist.rehydrate();
  }, []);

  const notices = useMemo(() => {
    const items: string[] = [];
    const verify = jobs.filter((j) => j.state === "verifying" && !j.cancelled);
    const drafts = jobs.filter((j) => j.state === "requested" && !j.cancelled);
    const live = jobs.filter((j) => (j.state === "executing" || j.state === "tracking") && !j.cancelled);
    if (verify.length) items.push(`${verify.length} trip waiting for shore verify`);
    if (drafts.length) items.push(`${drafts.length} unassigned request${drafts.length === 1 ? "" : "s"}`);
    for (const j of live.slice(0, 1)) {
      const v = vessels.find((x) => x.id === j.vesselId);
      items.push(`${j.boatId ? boatName(j.boatId) : "Boat"} underway to ${v?.name ?? "vessel"}`);
    }
    return items;
  }, [jobs, vessels]);

  return (
    <div className="min-h-dvh overflow-x-hidden bg-bg text-fg">
      <header className="bg-navy text-navy-fg">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 md:px-6">
          <Link to="/" className="flex min-w-0 items-center gap-3">
            <BrandMark light className="h-10 w-9" />
            <span className="min-w-0 leading-tight">
              <span className="block truncate text-lg font-semibold tracking-tight">Bahri Operations</span>
              <span className="block truncate text-xs text-navy-fg/70">Ras Tanura Operations Console</span>
            </span>
          </Link>

          <div className="flex items-center gap-2 md:gap-3">
            <div className="relative">
              <button
                type="button"
                className="relative flex size-11 items-center justify-center rounded-full text-navy-fg/85 hover:bg-navy-fg/10"
                aria-label="Notifications"
                onClick={() => setNotesOpen((v) => !v)}
              >
                <Bell className="size-5" />
                {notices.length > 0 ? (
                  <span className="absolute top-1.5 right-1.5 grid size-4 place-items-center rounded-full bg-danger text-[10px] font-bold text-primary-foreground">
                    {notices.length}
                  </span>
                ) : null}
              </button>
              {notesOpen ? (
                <div className="absolute right-0 z-50 mt-2 w-72 rounded-lg border border-border bg-surface p-3 text-fg shadow-[var(--shadow-panel)]">
                  <p className="mb-2 text-xs font-semibold text-muted">Alerts</p>
                  {notices.length === 0 ? (
                    <p className="text-sm text-muted">No alerts.</p>
                  ) : (
                    <ul className="flex flex-col gap-2">
                      {notices.map((n) => (
                        <li key={n} className="text-sm leading-snug">
                          {n}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ) : null}
            </div>
            <div className="hidden items-center gap-2 sm:flex">
              <div className="grid size-9 place-items-center rounded-full bg-white/12 text-xs font-semibold">OP</div>
              <div className="leading-tight">
                <p className="text-sm font-semibold">operations</p>
                <p className="text-xs text-navy-fg/65">Operations</p>
              </div>
              <ChevronDown className="size-4 opacity-60" />
            </div>
          </div>
        </div>
      </header>

      <nav className="sticky top-0 z-40 border-b border-border bg-surface">
        <div className="mx-auto flex max-w-7xl items-center gap-1 overflow-x-auto px-2 md:px-4">
          {NAV.map((item) => {
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex h-12 shrink-0 items-center gap-2 border-b-[3px] px-3 text-sm font-semibold whitespace-nowrap",
                  active
                    ? "border-primary text-primary"
                    : "border-transparent text-muted hover:text-fg",
                )}
              >
                <Icon className="size-4" />
                {item.label}
              </Link>
            );
          })}
          <div className="ml-auto hidden items-center gap-2 pr-2 md:flex">
            <RoleSwitch role={role} onChange={setRole} />
            <button
              type="button"
              onClick={() => {
                const next = !online;
                setOnline(next);
                toast(next ? "Link restored · queue flushed" : "Gulf dropout · stamps stay on device");
              }}
              className={cn(
                "flex h-9 items-center gap-1.5 rounded-md border px-2.5 text-xs font-semibold",
                online ? "border-ok/30 bg-ok-soft text-ok-fg" : "border-warn/30 bg-warn-soft text-warn-fg",
              )}
            >
              {online ? <Wifi className="size-3.5" /> : <WifiOff className="size-3.5" />}
              {online ? "Online" : "Offline"}
              {syncQueue.length > 0 ? <span className="tabular-nums">{syncQueue.length}</span> : null}
            </button>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Reset shift"
              onClick={() => {
                resetShift();
                toast("Shift reset to a fresh Ras Tanura day");
              }}
            >
              <RotateCcw className="size-4" />
            </Button>
          </div>
        </div>
      </nav>

      <main className="pb-8">{children}</main>

      <footer className="mt-4 border-t border-border bg-surface">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-5 text-xs text-muted sm:flex-row sm:items-center sm:justify-between md:px-6">
          <div className="flex items-center gap-2">
            <BrandMark className="h-8 w-7" />
            <div>
              <p className="font-semibold text-fg">Bahri Operations Console</p>
              <p>© 2026 Bahri. All rights reserved.</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <span>Version 1.0.0</span>
            <span className="text-border-strong">·</span>
            <span className="font-semibold text-ok">System healthy</span>
            <span className="hidden text-border-strong sm:inline">·</span>
            <LiveClock className="hidden text-left sm:block" />
          </div>
        </div>
      </footer>
    </div>
  );
}

function RoleSwitch({ role, onChange }: { role: Role; onChange: (r: Role) => void }) {
  const options: { id: Role; label: string }[] = [
    { id: "shore", label: "Shore" },
    ...BOATS.map((b) => ({ id: b.id as Role, label: b.short })),
  ];
  return (
    <div className="flex rounded-md border border-border bg-surface-2 p-0.5">
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          onClick={() => onChange(o.id)}
          className={cn(
            "h-8 rounded-sm px-2.5 text-xs font-semibold",
            role === o.id ? "bg-navy text-navy-fg" : "text-muted hover:text-fg",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
