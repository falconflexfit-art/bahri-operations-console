import { useEffect, useState } from "react";
import { formatClock, formatDate } from "@/lib/ops/format";
import { cn } from "@/lib/utils";

export function useNow(ms = 1000) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    setNow(Date.now());
    const id = window.setInterval(() => setNow(Date.now()), ms);
    return () => window.clearInterval(id);
  }, [ms]);
  return now ?? 0;
}

export function LiveClock({ withDate = false, className }: { withDate?: boolean; className?: string }) {
  const now = useNow();
  if (!now) {
    return <div className={cn("h-5 w-16", className)} aria-hidden />;
  }
  return (
    <div className={cn("text-right", className)}>
      <div className="font-mono text-sm tabular-nums whitespace-nowrap">{formatClock(now, true)} AST</div>
      {withDate ? <div className="text-xs tracking-wide text-subtle uppercase">{formatDate(now)}</div> : null}
    </div>
  );
}
