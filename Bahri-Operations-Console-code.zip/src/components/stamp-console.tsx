import { Check, Circle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { nextStamp, STAMP_HINT, STAMP_LABEL, STAMP_ORDER } from "@/lib/ops/format";
import { useOps } from "@/lib/ops/store";
import type { Job, Vessel } from "@/lib/ops/types";
import { StateBadge, TypeBadge } from "./state-badge";

export function StampConsole({ job, vessel }: { job: Job; vessel: Vessel }) {
  const stamp = useOps((s) => s.stamp);
  const online = useOps((s) => s.online);
  const next = nextStamp(job.timestamps);

  return (
    <div className="flex flex-col gap-4">
      <Card className="p-5">
        <div className="mb-1 flex items-center justify-between gap-2">
          <p className="font-mono text-xs text-subtle">{job.ref}</p>
          <StateBadge job={job} />
        </div>
        <h2 className="text-xl font-bold tracking-tight">{vessel.name}</h2>
        <p className="mt-1 text-sm text-muted">
          {vessel.berth} · {vessel.flag} · IMO {vessel.imo}
        </p>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <TypeBadge type={job.type} />
          {job.pax ? <span className="text-xs text-muted">{job.pax} pax</span> : null}
        </div>
        {job.notes ? <p className="mt-3 text-sm text-muted">{job.notes}</p> : null}
      </Card>

      {next ? (
        <button
          type="button"
          onClick={() => {
            const res = stamp(job.id, next);
            if (res.ok) {
              toast(`${STAMP_LABEL[next]} recorded${online ? "" : " · queued"}`);
            } else toast.error(res.message);
          }}
          className="flex min-h-28 flex-col items-center justify-center rounded-xl bg-primary px-6 py-5 text-center text-primary-foreground transition-transform duration-150 active:scale-[0.98]"
        >
          <span className="text-xs font-semibold tracking-wide uppercase opacity-80">Record next event</span>
          <span className="mt-1 text-2xl font-bold tracking-tight">{STAMP_LABEL[next]}</span>
          <span className="mt-1 text-sm opacity-80">{STAMP_HINT[next]}</span>
        </button>
      ) : (
        <Card className="border-ok/30 bg-ok-soft p-5 text-center">
          <p className="text-sm font-semibold text-ok-fg">Six stamps in. Shore will verify and close.</p>
        </Card>
      )}

      <ol className="flex flex-col gap-1.5">
        {STAMP_ORDER.map((key, i) => {
          const rec = job.timestamps[key];
          const isNext = key === next;
          return (
            <li key={key} className="flex items-center gap-3 rounded-md border border-border bg-surface px-3 py-3">
              <span className="flex size-8 shrink-0 items-center justify-center rounded-sm bg-surface-2 text-subtle">
                {rec ? <Check className="size-4 text-ok" /> : <Circle className="size-3.5" />}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold">
                  {i + 1}. {STAMP_LABEL[key]}
                </p>
                <p className="text-xs text-subtle">{STAMP_HINT[key]}</p>
              </div>
              {rec ? (
                <div className="text-right">
                  <p className="font-mono text-sm tabular-nums">{rec.deviceClock}</p>
                  <p className="text-[11px] tracking-wide text-subtle uppercase">{rec.pendingSync ? "queued" : "device"}</p>
                </div>
              ) : isNext ? (
                <Button
                  size="sm"
                  onClick={() => {
                    const res = stamp(job.id, key);
                    if (!res.ok) toast.error(res.message);
                    else toast(`${STAMP_LABEL[key]} recorded`);
                  }}
                >
                  Stamp
                </Button>
              ) : (
                <span className="font-mono text-xs text-subtle">—</span>
              )}
            </li>
          );
        })}
      </ol>
    </div>
  );
}
