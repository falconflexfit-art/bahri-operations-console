import { createFileRoute } from "@tanstack/react-router";
import { Anchor, CalendarClock, CheckCircle2, Plus, Ship } from "lucide-react";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { CreateJobForm } from "@/components/create-job-form";
import { DispatchSheet, NewRequestSheet, VerifySheet } from "@/components/job-forms";
import { JobRow } from "@/components/job-row";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { formatClock } from "@/lib/ops/format";
import { BOATS } from "@/lib/ops/constants";
import { boatStatus, tripsToday, useOps } from "@/lib/ops/store";
import type { Job } from "@/lib/ops/types";
import { cn } from "@/lib/utils";
import { useNow } from "@/components/clock";

export const Route = createFileRoute("/")({ component: Home });

type Tab = "all" | "active" | "upcoming" | "done";

function isActive(j: Job) {
  return !j.cancelled && (j.state === "dispatched" || j.state === "tracking" || j.state === "executing" || j.state === "verifying");
}
function isUpcoming(j: Job) {
  return !j.cancelled && (j.state === "requested" || j.state === "planned");
}
function isDone(j: Job) {
  return !j.cancelled && j.state === "reported";
}

function Home() {
  const jobs = useOps((s) => s.jobs);
  const vessels = useOps((s) => s.vessels);
  const [tab, setTab] = useState<Tab>("all");
  const [formOpen, setFormOpen] = useState(true);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [dispatchJob, setDispatchJob] = useState<Job | null>(null);
  const [verifyJob, setVerifyJob] = useState<Job | null>(null);
  const now = useNow(30_000);

  const live = jobs.filter((j) => !j.cancelled);
  const active = live.filter(isActive);
  const upcoming = live.filter(isUpcoming);
  const done = live.filter(isDone);
  const available = BOATS.filter((b) => boatStatus(jobs, b.id) === "at_base").length;

  const visible = useMemo(() => {
    if (tab === "active") return active;
    if (tab === "upcoming") return upcoming;
    if (tab === "done") return done;
    return live;
  }, [tab, active, upcoming, done, live]);

  const grouped = [
    { key: "active", title: "Active", jobs: visible.filter(isActive), tone: "danger" as const },
    { key: "upcoming", title: "Upcoming", jobs: visible.filter(isUpcoming), tone: "warn" as const },
    { key: "done", title: "Completed today", jobs: visible.filter(isDone), tone: "ok" as const },
  ].filter((g) => g.jobs.length > 0);

  return (
    <AppShell>
      <div className="mx-auto max-w-7xl px-4 py-5 md:px-6 md:py-6">
        <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Stat
            label="Active jobs"
            value={String(active.length)}
            hint={active.length ? "Underway / assigned" : "None live"}
            icon={Anchor}
            tone="info"
          />
          <Stat
            label="Today's jobs"
            value={String(live.length)}
            hint={`${tripsToday(jobs)} completed`}
            icon={CheckCircle2}
            tone="ok"
          />
          <Stat
            label="Upcoming"
            value={String(upcoming.length)}
            hint="Next 24h"
            icon={CalendarClock}
            tone="warn"
          />
          <Stat
            label="Boats status"
            value={`${available} / ${BOATS.length}`}
            hint={`${available} available`}
            icon={Ship}
            tone="info"
          />
        </div>

        <div className="grid items-start gap-4 lg:grid-cols-[1.15fr_0.85fr]">
          <Card className="overflow-hidden p-0">
            <div className="flex items-center justify-between gap-3 px-4 py-4">
              <h2 className="text-lg font-bold tracking-tight">Dispatch board</h2>
              <p className="text-[11px] text-muted">Last updated: {now ? formatClock(now) : "—"}</p>
            </div>
            <div className="flex gap-2 overflow-x-auto px-4 pb-3">
              {(
                [
                  ["all", `All jobs (${live.length})`],
                  ["active", `Active (${active.length})`],
                  ["upcoming", `Upcoming (${upcoming.length})`],
                  ["done", `Completed (${done.length})`],
                ] as const
              ).map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setTab(key)}
                  className={cn(
                    "h-9 shrink-0 rounded-md px-3 text-xs font-semibold",
                    tab === key ? "bg-navy text-navy-fg" : "bg-surface-2 text-muted hover:text-fg",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="px-4 pb-4">
              {grouped.length === 0 ? (
                <p className="py-10 text-center text-sm text-muted">No jobs in this view.</p>
              ) : (
                grouped.map((g) => (
                  <div key={g.key} className="mb-4 last:mb-0">
                    <div className="mb-2 flex items-center gap-2 text-xs font-bold">
                      <span
                        className={cn(
                          "grid size-3.5 place-items-center rounded-full border-2",
                          g.tone === "danger" && "border-danger text-danger",
                          g.tone === "warn" && "border-warn text-warn",
                          g.tone === "ok" && "border-ok text-ok",
                        )}
                      />
                      {g.title}
                    </div>
                    <div className="flex flex-col gap-2">
                      {g.jobs.map((j) => (
                        <div key={j.id} className="flex min-w-0 items-stretch gap-2">
                          <div className="min-w-0 flex-1">
                            <JobRow
                              job={j}
                              vessel={vessels.find((v) => v.id === j.vesselId)}
                              highlight={isActive(j)}
                            />
                          </div>
                          {isUpcoming(j) ? (
                            <Button
                              variant="secondary"
                              className="hidden h-11 shrink-0 self-center sm:inline-flex"
                              onClick={() => setDispatchJob(j)}
                            >
                              Assign
                            </Button>
                          ) : null}
                          {j.state === "verifying" ? (
                            <Button className="hidden h-11 shrink-0 self-center sm:inline-flex" onClick={() => setVerifyJob(j)}>
                              Verify
                            </Button>
                          ) : null}
                        </div>
                      ))}
                    </div>
                  </div>
                ))
              )}
            </div>
          </Card>

          <div className="hidden lg:block">
            {formOpen ? (
              <Card className="p-0">
                <div className="flex items-center justify-between px-4 py-4">
                  <h2 className="text-lg font-bold tracking-tight">Create new job</h2>
                  <button
                    type="button"
                    className="grid size-9 place-items-center rounded-md text-muted hover:bg-surface-2 hover:text-fg"
                    onClick={() => setFormOpen(false)}
                    aria-label="Close form"
                  >
                    ×
                  </button>
                </div>
                <div className="px-4 pb-4">
                  <CreateJobForm />
                </div>
              </Card>
            ) : (
              <Button className="w-full" size="lg" onClick={() => setFormOpen(true)}>
                <Plus className="size-4" />
                Create new job
              </Button>
            )}
          </div>
        </div>

        <div className="mt-4 lg:hidden">
          <Button className="w-full" size="lg" onClick={() => setSheetOpen(true)}>
            <Plus className="size-4" />
            Create new job
          </Button>
        </div>
      </div>
      <NewRequestSheet open={sheetOpen} onOpenChange={setSheetOpen} />
      <DispatchSheet job={dispatchJob} open={!!dispatchJob} onOpenChange={(v) => !v && setDispatchJob(null)} />
      <VerifySheet job={verifyJob} open={!!verifyJob} onOpenChange={(v) => !v && setVerifyJob(null)} />
    </AppShell>
  );
}

function Stat({
  label,
  value,
  hint,
  icon: Icon,
  tone,
}: {
  label: string;
  value: string;
  hint: string;
  icon: typeof Anchor;
  tone: "info" | "ok" | "warn";
}) {
  return (
    <Card className="flex items-center justify-between gap-3 p-4">
      <div className="min-w-0">
        <p className="text-xs font-semibold text-muted">{label}</p>
        <p className="mt-1 text-[1.65rem] font-extrabold tabular-nums tracking-tight">{value}</p>
        <p
          className={cn(
            "mt-0.5 text-xs font-semibold",
            tone === "ok" && "text-ok",
            tone === "warn" && "text-warn",
            tone === "info" && "text-primary",
          )}
        >
          {hint}
        </p>
      </div>
      <span
        className={cn(
          "grid size-10 shrink-0 place-items-center rounded-full",
          tone === "ok" && "bg-ok-soft text-ok",
          tone === "warn" && "bg-warn-soft text-warn",
          tone === "info" && "bg-info-soft text-primary",
        )}
      >
        <Icon className="size-5" />
      </span>
    </Card>
  );
}
