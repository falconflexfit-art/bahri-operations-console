import { createFileRoute } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { DispatchSheet, NewRequestSheet } from "@/components/job-forms";
import { JobRow } from "@/components/job-row";
import { Button } from "@/components/ui/button";
import { PIPELINE } from "@/lib/ops/format";
import { useOps } from "@/lib/ops/store";
import type { Job, JobState } from "@/lib/ops/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/jobs")({ component: JobsPage });

function JobsPage() {
  const jobs = useOps((s) => s.jobs);
  const vessels = useOps((s) => s.vessels);
  const [filter, setFilter] = useState<JobState | "live" | "all">("live");
  const [newOpen, setNewOpen] = useState(false);
  const [dispatchJob, setDispatchJob] = useState<Job | null>(null);

  const visible = useMemo(() => {
    const open = jobs.filter((j) => !j.cancelled);
    if (filter === "all") return open;
    if (filter === "live") return open.filter((j) => j.state !== "reported");
    return open.filter((j) => j.state === filter);
  }, [jobs, filter]);

  return (
    <AppShell>
      <div className="mx-auto max-w-4xl px-4 py-5 md:px-6 md:py-6">
        <div className="mb-5 flex items-end justify-between gap-3">
          <div>
            <p className="text-xs font-semibold tracking-wide text-muted uppercase">State model</p>
            <h1 className="mt-1 text-3xl font-bold tracking-tight">Jobs</h1>
          </div>
          <Button onClick={() => setNewOpen(true)}>
            <Plus className="size-4" />
            Create job
          </Button>
        </div>

        <div className="mb-4 flex gap-1 overflow-x-auto pb-1">
          {(["live", "all", ...PIPELINE.map((p) => p.state)] as const).map((key) => {
            const label = key === "live" ? "Live" : key === "all" ? "All" : PIPELINE.find((p) => p.state === key)?.label;
            const active = filter === key;
            return (
              <button
                key={key}
                type="button"
                onClick={() => setFilter(key)}
                className={cn(
                  "h-9 shrink-0 rounded-full border px-3 text-xs font-semibold",
                  active ? "border-navy bg-navy text-navy-fg" : "border-border text-muted",
                )}
              >
                {label}
              </button>
            );
          })}
        </div>

        <div className="flex flex-col gap-2">
          {visible.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted">Nothing in this column.</p>
          ) : (
            visible.map((j) => (
              <div key={j.id} className="flex min-w-0 items-stretch gap-2">
                <div className="min-w-0 flex-1">
                  <JobRow job={j} vessel={vessels.find((v) => v.id === j.vesselId)} />
                </div>
                {j.state === "requested" || j.state === "planned" ? (
                  <Button
                    variant="secondary"
                    className="hidden h-11 shrink-0 self-center px-3 sm:inline-flex"
                    onClick={() => setDispatchJob(j)}
                  >
                    Assign
                  </Button>
                ) : null}
              </div>
            ))
          )}
        </div>
      </div>
      <NewRequestSheet open={newOpen} onOpenChange={setNewOpen} />
      <DispatchSheet job={dispatchJob} open={!!dispatchJob} onOpenChange={(v) => !v && setDispatchJob(null)} />
    </AppShell>
  );
}
