import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { DispatchSheet, VerifySheet } from "@/components/job-forms";
import { StateBadge, TypeBadge } from "@/components/state-badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CAPTAINS } from "@/lib/ops/constants";
import {
  boatName,
  cycleMinutes,
  formatClock,
  formatDuration,
  PIPELINE,
  STAMP_HINT,
  STAMP_LABEL,
  STAMP_ORDER,
  stateIndex,
} from "@/lib/ops/format";
import { useOps } from "@/lib/ops/store";

export const Route = createFileRoute("/jobs/$jobId")({ component: JobDetail });

function JobDetail() {
  const { jobId } = Route.useParams();
  const jobs = useOps((s) => s.jobs);
  const vessels = useOps((s) => s.vessels);
  const cancelJob = useOps((s) => s.cancelJob);
  const job = jobs.find((j) => j.id === jobId);
  const vessel = job ? vessels.find((v) => v.id === job.vesselId) : undefined;
  const [dispatchOpen, setDispatchOpen] = useState(false);
  const [verifyOpen, setVerifyOpen] = useState(false);

  if (!job || !vessel) {
    return (
      <AppShell>
        <div className="px-5 py-16 text-center text-muted">Job not found.</div>
      </AppShell>
    );
  }

  const cycle = cycleMinutes(job);
  const idx = stateIndex(job.state);
  const captain = CAPTAINS.find((c) => c.id === job.captainId);

  return (
    <AppShell>
      <div className="mx-auto max-w-2xl px-4 py-5 md:px-6 md:py-6">
        <Link to="/jobs" className="text-sm font-semibold text-primary hover:underline">
          ← Jobs
        </Link>
        <div className="mt-3 flex items-start justify-between gap-3">
          <div>
            <p className="font-mono text-xs text-subtle">{job.ref}</p>
            <h1 className="text-3xl font-bold tracking-tight">{vessel.name}</h1>
            <p className="mt-1 text-sm text-muted">
              {vessel.berth} · {vessel.type.toUpperCase()} · IMO {vessel.imo}
            </p>
          </div>
          <StateBadge job={job} />
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <TypeBadge type={job.type} />
          {job.boatId ? (
            <span className="rounded-full border border-border px-2 py-0.5 text-xs font-medium text-muted">
              {boatName(job.boatId)}
            </span>
          ) : null}
          {captain ? (
            <span className="rounded-full border border-border px-2 py-0.5 text-xs font-medium text-muted">{captain.name}</span>
          ) : null}
          {job.pax ? (
            <span className="rounded-full border border-border px-2 py-0.5 text-xs font-medium text-muted">{job.pax} pax</span>
          ) : null}
          {job.tripCounted ? (
            <span className="rounded-full border border-ok/30 bg-ok-soft px-2 py-0.5 text-xs font-medium text-ok-fg">
              Trip counted
            </span>
          ) : null}
        </div>

        <ol className="mt-6 flex gap-1">
          {PIPELINE.map((p, i) => (
            <li key={p.state} className="flex-1">
              <div className={`h-1 rounded-full ${i <= idx ? "bg-primary" : "bg-border"}`} />
              <p className="mt-1 hidden text-[10px] font-semibold tracking-wide text-subtle uppercase sm:block">{p.label}</p>
            </li>
          ))}
        </ol>

        <Card className="mt-6 p-4">
          <p className="text-xs font-semibold text-muted">Request</p>
          <p className="mt-1 text-sm">
            {job.requestedBy} · {formatClock(job.requestedAt)}
          </p>
          {job.notes ? <p className="mt-2 text-sm text-muted">{job.notes}</p> : null}
          {cycle != null ? <p className="mt-3 font-mono text-sm tabular-nums">Cycle {formatDuration(cycle)}</p> : null}
        </Card>

        <h2 className="mt-8 text-sm font-bold">Device log</h2>
        <ol className="mt-3 flex flex-col gap-1.5">
          {STAMP_ORDER.map((key, i) => {
            const rec = job.timestamps[key];
            return (
              <li key={key} className="flex items-center justify-between rounded-md border border-border bg-surface px-3 py-3">
                <div>
                  <p className="text-sm font-semibold">
                    {i + 1}. {STAMP_LABEL[key]}
                  </p>
                  <p className="text-xs text-subtle">{STAMP_HINT[key]}</p>
                </div>
                {rec ? (
                  <div className="text-right">
                    <p className="font-mono text-sm tabular-nums">{rec.deviceClock}</p>
                    <p className="text-[11px] tracking-wide text-subtle uppercase">
                      {rec.pendingSync ? "queued" : "device"}
                    </p>
                  </div>
                ) : (
                  <span className="font-mono text-xs text-subtle">open</span>
                )}
              </li>
            );
          })}
        </ol>

        {job.verifyNotes ? (
          <Card className="mt-4 p-4">
            <p className="text-xs font-semibold text-muted">Verify</p>
            <p className="mt-1 text-sm">{job.verifyNotes}</p>
          </Card>
        ) : null}

        <div className="mt-6 flex flex-wrap gap-2">
          {job.state === "requested" || job.state === "planned" ? (
            <>
              <Button onClick={() => setDispatchOpen(true)}>Assign / dispatch</Button>
              <Button variant="danger" onClick={() => cancelJob(job.id)}>
                Cancel
              </Button>
            </>
          ) : null}
          {job.state === "verifying" ? <Button onClick={() => setVerifyOpen(true)}>Verify and close</Button> : null}
          {job.boatId && job.state !== "reported" && job.state !== "requested" ? (
            <Button variant="secondary" asChild>
              <Link to="/crew" search={{ boat: job.boatId }}>
                Crew console
              </Link>
            </Button>
          ) : null}
        </div>
      </div>
      <DispatchSheet job={job} open={dispatchOpen} onOpenChange={setDispatchOpen} />
      <VerifySheet job={job} open={verifyOpen} onOpenChange={setVerifyOpen} />
    </AppShell>
  );
}
