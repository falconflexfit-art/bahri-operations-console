import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { BoatStatusBadge } from "@/components/state-badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BOATS, CAPTAINS } from "@/lib/ops/constants";
import { boatName } from "@/lib/ops/format";
import { activeJobFor, boatStatus, useOps } from "@/lib/ops/store";

export const Route = createFileRoute("/people")({ component: PeoplePage });

function PeoplePage() {
  const jobs = useOps((s) => s.jobs);
  const vessels = useOps((s) => s.vessels);

  return (
    <AppShell>
      <div className="mx-auto max-w-5xl px-4 py-5 md:px-6 md:py-6">
        <p className="text-xs font-semibold tracking-wide text-muted uppercase">Duty crew</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">People</h1>
        <p className="mt-2 max-w-xl text-sm text-muted">
          Masters and officers on Yara and Jenan this shift. Open the crew console to stamp events on device time.
        </p>

        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          {CAPTAINS.map((c) => {
            const boat = BOATS.find((b) => b.id === c.boatId)!;
            const status = boatStatus(jobs, c.boatId);
            const job = activeJobFor(jobs, c.boatId);
            const vessel = vessels.find((v) => v.id === job?.vesselId);
            const onDuty = Boolean(job && (job.captainId === c.id || (!job.captainId && c.rank === "Master")));
            return (
              <Card key={c.id} className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-muted">{c.rank}</p>
                    <h2 className="text-lg font-bold tracking-tight">{c.name}</h2>
                    <p className="text-sm text-muted">{boat.name}</p>
                  </div>
                  <BoatStatusBadge status={onDuty ? status : "at_base"} />
                </div>
                <p className="mt-3 text-sm text-muted">
                  {onDuty && vessel ? `On job · ${vessel.name}` : `${boatName(c.boatId)} at base`}
                </p>
                <Button asChild variant="secondary" className="mt-4" size="sm">
                  <Link to="/crew" search={{ boat: c.boatId }}>
                    Crew console
                  </Link>
                </Button>
              </Card>
            );
          })}
        </div>
      </div>
    </AppShell>
  );
}
