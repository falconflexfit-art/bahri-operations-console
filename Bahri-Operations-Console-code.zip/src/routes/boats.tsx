import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { OpsPlot } from "@/components/ops-plot";
import { BoatStatusBadge } from "@/components/state-badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BOATS, CAPTAINS } from "@/lib/ops/constants";
import { boatName, formatClock, JOB_TYPE_LABEL } from "@/lib/ops/format";
import { activeJobFor, boatStatus, tripsToday, useOps } from "@/lib/ops/store";

export const Route = createFileRoute("/boats")({ component: BoatsPage });

function BoatsPage() {
  const jobs = useOps((s) => s.jobs);
  const vessels = useOps((s) => s.vessels);

  return (
    <AppShell>
      <div className="mx-auto max-w-7xl px-4 py-5 md:px-6 md:py-6">
        <p className="text-xs font-semibold tracking-wide text-muted uppercase">Ras Tanura fleet</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">Boats</h1>
        <p className="mt-2 max-w-xl text-sm text-muted">
          Two OSVs on the jetty. Positions on the plot interpolate from the six-stamp log — not GPS.
        </p>

        <div className="mt-5 grid gap-3 md:grid-cols-2">
          {BOATS.map((b) => {
            const job = activeJobFor(jobs, b.id);
            const vessel = vessels.find((v) => v.id === job?.vesselId);
            const status = boatStatus(jobs, b.id);
            const master = CAPTAINS.find((c) => c.boatId === b.id && c.rank === "Master");
            return (
              <Card key={b.id} className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-mono text-xs text-subtle">{b.callsign}</p>
                    <h2 className="text-xl font-bold tracking-tight">{b.name}</h2>
                    <p className="text-sm text-muted">{b.class}</p>
                  </div>
                  <BoatStatusBadge status={status} />
                </div>
                <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <dt className="text-xs text-muted">Master</dt>
                    <dd className="font-medium">{master?.name ?? "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-muted">Trips today</dt>
                    <dd className="font-medium tabular-nums">{tripsToday(jobs, b.id)}</dd>
                  </div>
                </dl>
                {job && vessel ? (
                  <div className="mt-4 rounded-md border border-border bg-bg p-3">
                    <p className="text-sm font-semibold">{vessel.name}</p>
                    <p className="text-xs text-muted">
                      {JOB_TYPE_LABEL[job.type]} · {vessel.berth} · {formatClock(job.scheduledAt ?? job.requestedAt)}
                    </p>
                    <Button asChild className="mt-3" size="sm">
                      <Link to="/crew" search={{ boat: b.id }}>
                        Open crew console
                      </Link>
                    </Button>
                  </div>
                ) : (
                  <p className="mt-4 text-sm text-muted">{boatName(b.id)} at Ras Tanura base. Waiting for dispatch.</p>
                )}
              </Card>
            );
          })}
        </div>

        <OpsPlot vessels={vessels} jobs={jobs} className="mt-5 h-[420px] min-h-[280px]" />
      </div>
    </AppShell>
  );
}
