import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { AppShell } from "@/components/app-shell";
import { Card } from "@/components/ui/card";
import {
  boatName,
  cycleMinutes,
  formatClock,
  formatDate,
  formatDuration,
  JOB_TYPE_LABEL,
  STAMP_LABEL,
  STAMP_ORDER,
} from "@/lib/ops/format";
import { tripsToday, useOps } from "@/lib/ops/store";
import type { JobType } from "@/lib/ops/types";
import { useNow } from "@/components/clock";

export const Route = createFileRoute("/report")({ component: ReportPage });

function ReportPage() {
  const jobs = useOps((s) => s.jobs);
  const vessels = useOps((s) => s.vessels);
  const now = useNow(30_000);
  const counted = jobs.filter((j) => j.tripCounted && !j.cancelled);
  const byBoat = {
    yara: counted.filter((j) => j.boatId === "yara"),
    jenan: counted.filter((j) => j.boatId === "jenan"),
  };
  const byType = useMemo(() => {
    const map = new Map<JobType, number>();
    for (const j of counted) map.set(j.type, (map.get(j.type) ?? 0) + 1);
    return [...map.entries()].sort((a, b) => b[1] - a[1]);
  }, [counted]);
  const cycles = counted.map(cycleMinutes).filter((n): n is number => n != null);
  const mean = cycles.length ? Math.round(cycles.reduce((a, b) => a + b, 0) / cycles.length) : 0;

  return (
    <AppShell>
      <div className="mx-auto max-w-3xl px-4 py-5 md:px-6 md:py-6">
        <p className="text-xs font-semibold tracking-wide text-muted uppercase">Daily close</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">Shift report</h1>
        <p className="mt-2 text-sm text-muted">
          {now ? formatDate(now) : "Ras Tanura"} · Ras Tanura · every returned trip is in this count.
        </p>

        <div className="mt-6 grid grid-cols-3 gap-3">
          <Card className="p-4">
            <p className="text-xs font-semibold text-muted">Trips</p>
            <p className="text-3xl font-extrabold tabular-nums">{tripsToday(jobs)}</p>
          </Card>
          <Card className="p-4">
            <p className="text-xs font-semibold text-muted">Yara</p>
            <p className="text-3xl font-extrabold tabular-nums">{byBoat.yara.length}</p>
          </Card>
          <Card className="p-4">
            <p className="text-xs font-semibold text-muted">Jenan</p>
            <p className="text-3xl font-extrabold tabular-nums">{byBoat.jenan.length}</p>
          </Card>
        </div>

        <Card className="mt-4 p-4">
          <p className="text-xs font-semibold text-muted">Mean cycle</p>
          <p className="text-2xl font-extrabold tabular-nums">{mean ? formatDuration(mean) : "—"}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            {byType.map(([t, n]) => (
              <span key={t} className="rounded-full border border-border px-2 py-0.5 text-xs font-medium text-muted">
                {JOB_TYPE_LABEL[t]} {n}
              </span>
            ))}
          </div>
        </Card>

        <h2 className="mt-8 text-sm font-bold">Trip log</h2>
        <div className="mt-3 flex flex-col gap-2">
          {counted.length === 0 ? (
            <p className="text-sm text-muted">No counted trips yet.</p>
          ) : (
            counted.map((j) => {
              const v = vessels.find((x) => x.id === j.vesselId);
              const c = cycleMinutes(j);
              return (
                <Card key={j.id} className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-mono text-xs text-subtle">{j.ref}</p>
                      <p className="font-semibold">{v?.name}</p>
                      <p className="text-xs text-muted">
                        {j.boatId ? boatName(j.boatId) : "—"} · {JOB_TYPE_LABEL[j.type]}
                        {c != null ? ` · ${formatDuration(c)}` : ""}
                      </p>
                    </div>
                    <p className="font-mono text-xs tabular-nums text-subtle">
                      {j.timestamps.departed_base ? formatClock(j.timestamps.departed_base.at) : "—"}
                      {" → "}
                      {j.timestamps.returned_base ? formatClock(j.timestamps.returned_base.at) : "—"}
                    </p>
                  </div>
                  <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1">
                    {STAMP_ORDER.map((k) => (
                      <div key={k}>
                        <dt className="text-xs text-subtle">{STAMP_LABEL[k]}</dt>
                        <dd className="font-mono text-xs tabular-nums">
                          {j.timestamps[k]?.deviceClock ?? "—"}
                        </dd>
                      </div>
                    ))}
                  </dl>
                </Card>
              );
            })
          )}
        </div>
      </div>
    </AppShell>
  );
}
