import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { AppShell } from "@/components/app-shell";
import { StampConsole } from "@/components/stamp-console";
import { BoatStatusBadge } from "@/components/state-badge";
import { Card } from "@/components/ui/card";
import { BOATS } from "@/lib/ops/constants";
import { boatName } from "@/lib/ops/format";
import { activeJobFor, boatStatus, useOps } from "@/lib/ops/store";
import type { BoatId } from "@/lib/ops/types";
import { cn } from "@/lib/utils";

type CrewSearch = { boat?: BoatId };

export const Route = createFileRoute("/crew")({
  validateSearch: (s: Record<string, unknown>): CrewSearch => ({
    boat: s.boat === "jenan" || s.boat === "yara" ? s.boat : undefined,
  }),
  component: CrewPage,
});

function CrewPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const role = useOps((s) => s.role);
  const setRole = useOps((s) => s.setRole);
  const jobs = useOps((s) => s.jobs);
  const vessels = useOps((s) => s.vessels);

  useEffect(() => {
    if (search.boat) setRole(search.boat);
  }, [search.boat, setRole]);

  const boatId: BoatId = role === "yara" || role === "jenan" ? role : (search.boat ?? "yara");
  const job = activeJobFor(jobs, boatId);
  const vessel = job ? vessels.find((v) => v.id === job.vesselId) : undefined;
  const status = boatStatus(jobs, boatId);
  const boat = BOATS.find((b) => b.id === boatId)!;

  return (
    <AppShell>
      <div className="mx-auto max-w-lg px-4 py-5 md:py-6">
        <div className="mb-4 flex rounded-md border border-border bg-surface p-0.5">
          {BOATS.map((b) => (
            <button
              key={b.id}
              type="button"
              onClick={() => {
                setRole(b.id);
                void navigate({ to: "/crew", search: { boat: b.id } });
              }}
              className={cn(
                "h-11 flex-1 rounded-sm text-sm font-semibold",
                boatId === b.id ? "bg-navy text-navy-fg" : "text-muted",
              )}
            >
              {b.short}
            </button>
          ))}
        </div>

        <div className="mb-5 flex items-start justify-between gap-3">
          <div>
            <p className="font-mono text-xs text-subtle">{boat.callsign}</p>
            <h1 className="text-3xl font-bold tracking-tight">{boat.name}</h1>
            <p className="text-sm text-muted">Device log · stamps at local clock, even offline</p>
          </div>
          <BoatStatusBadge status={status} />
        </div>

        {job && vessel ? (
          <StampConsole job={job} vessel={vessel} />
        ) : (
          <Card className="p-6 text-center">
            <p className="text-base font-semibold">{boatName(boatId)} is at Ras Tanura base</p>
            <p className="mt-2 text-sm text-muted">No dispatched trip. Shore will assign the next job.</p>
          </Card>
        )}
      </div>
    </AppShell>
  );
}
