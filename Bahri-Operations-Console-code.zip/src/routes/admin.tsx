import { createFileRoute } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BOATS } from "@/lib/ops/constants";
import { useOps } from "@/lib/ops/store";
import type { Role } from "@/lib/ops/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/admin")({ component: AdminPage });

function AdminPage() {
  const { role, setRole, online, setOnline, resetShift, syncQueue, jobs } = useOps();
  const options: { id: Role; label: string }[] = [
    { id: "shore", label: "Shore / operations" },
    ...BOATS.map((b) => ({ id: b.id as Role, label: b.name })),
  ];

  return (
    <AppShell>
      <div className="mx-auto max-w-3xl px-4 py-5 md:px-6 md:py-6">
        <p className="text-xs font-semibold tracking-wide text-muted uppercase">Console</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">Admin</h1>
        <p className="mt-2 text-sm text-muted">
          Role, link, and shift controls. Stamps stay on this device if the Gulf link drops.
        </p>

        <Card className="mt-5 p-5">
          <h2 className="text-sm font-bold">Acting as</h2>
          <div className="mt-3 flex flex-col gap-2">
            {options.map((o) => (
              <button
                key={o.id}
                type="button"
                onClick={() => setRole(o.id)}
                className={cn(
                  "flex h-12 items-center rounded-md border px-4 text-left text-sm font-semibold",
                  role === o.id ? "border-primary bg-info-soft text-fg" : "border-border text-muted hover:text-fg",
                )}
              >
                {o.label}
              </button>
            ))}
          </div>
        </Card>

        <Card className="mt-3 p-5">
          <h2 className="text-sm font-bold">Connectivity</h2>
          <p className="mt-1 text-sm text-muted">
            {online ? "Link up." : "Offline."} Queue {syncQueue.length} · {jobs.length} jobs on device.
          </p>
          <Button
            className="mt-4"
            variant={online ? "secondary" : "default"}
            onClick={() => {
              const next = !online;
              setOnline(next);
              toast(next ? "Link restored · queue flushed" : "Gulf dropout · stamps stay on device");
            }}
          >
            {online ? "Simulate dropout" : "Restore link"}
          </Button>
        </Card>

        <Card className="mt-3 p-5">
          <h2 className="text-sm font-bold">Shift</h2>
          <p className="mt-1 text-sm text-muted">Reset restores the seeded Ras Tanura day. Local only — nothing is sent to a server.</p>
          <Button
            className="mt-4"
            variant="danger"
            onClick={() => {
              resetShift();
              toast("Shift reset");
            }}
          >
            Reset shift
          </Button>
        </Card>

        <Card className="mt-3 p-5">
          <h2 className="text-sm font-bold">Platform readiness</h2>
          <ul className="mt-3 grid gap-3 sm:grid-cols-2">
            {[
              ["Status", "Ready"],
              ["Environment", "Operations console"],
              ["Region", "Ras Tanura / AST"],
              ["Device store", "Reachable"],
            ].map(([k, v]) => (
              <li key={k} className="flex items-center gap-2 text-sm">
                <span className="grid size-4 place-items-center rounded-full bg-ok text-primary-foreground">
                  <Check className="size-2.5" strokeWidth={3} />
                </span>
                <span>
                  <span className="block text-[11px] text-muted">{k}</span>
                  <span className="font-semibold">{v}</span>
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </AppShell>
  );
}
