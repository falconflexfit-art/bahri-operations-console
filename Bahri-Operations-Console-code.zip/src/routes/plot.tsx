import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/plot")({
  component: () => <Navigate to="/boats" />,
});
