import { BASE_BERTH } from "./constants";
import type { Job, JobType, OpsSnapshot, Stamp, StampKey, Vessel } from "./types";

function iso(ms: number) {
  return new Date(ms).toISOString();
}

function stampAt(ms: number, pending = false): Stamp {
  const d = new Date(ms);
  const clock = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Riyadh",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).format(d);
  return { at: iso(ms), deviceClock: clock, source: "device", pendingSync: pending };
}

function tripStamps(departMs: number, cycleMin: number): Record<StampKey, Stamp> {
  const m = 60_000;
  const alongside = departMs + 32 * m;
  const opsStart = alongside + 4 * m;
  const opsEnd = opsStart + Math.max(8, Math.round(cycleMin * 0.22)) * m;
  const castOff = opsEnd + 5 * m;
  const back = departMs + cycleMin * m;
  return {
    departed_base: stampAt(departMs),
    alongside: stampAt(alongside),
    ops_start: stampAt(opsStart),
    ops_complete: stampAt(opsEnd),
    departed_vessel: stampAt(castOff),
    returned_base: stampAt(back),
  };
}

export const VESSELS: Vessel[] = [
  { id: "v1", name: "Front Queen", type: "vlcc", flag: "MH", imo: "9731101", berth: "RT-A3", lat: 26.668, lng: 50.262, agent: "Bahri Agency" },
  { id: "v2", name: "Maran Antares", type: "vlcc", flag: "GR", imo: "9412036", berth: "RT-A5", lat: 26.692, lng: 50.288, agent: "Bahri Agency" },
  { id: "v3", name: "DHT Tiger", type: "vlcc", flag: "HK", imo: "9592200", berth: "RT-A2", lat: 26.651, lng: 50.248, agent: "Gulf Agency" },
  { id: "v4", name: "STI Excel", type: "product", flag: "MH", imo: "9686748", berth: "RT-A7", lat: 26.714, lng: 50.312, agent: "Bahri Agency" },
  { id: "v5", name: "Al Jasrah", type: "lng", flag: "MT", imo: "9684588", berth: "RT-L1", lat: 26.638, lng: 50.301, agent: "Bahri Agency" },
  { id: "v6", name: "Nordic Freedom", type: "product", flag: "SG", imo: "9724415", berth: "RT-A4", lat: 26.679, lng: 50.274, agent: "Wilhelmsen" },
  { id: "v7", name: "Minerva Zoe", type: "chemical", flag: "GR", imo: "9748122", berth: "RT-A8", lat: 26.725, lng: 50.336, agent: "Bahri Agency" },
  { id: "v8", name: "Pacific Diamond", type: "bulk", flag: "PA", imo: "9617743", berth: "RT-A6", lat: 26.701, lng: 50.254, agent: "Gulf Agency" },
  { id: "v9", name: "CPO Norway", type: "product", flag: "LR", imo: "9693301", berth: "RT-A1", lat: 26.646, lng: 50.228, agent: "Bahri Agency" },
  { id: "v10", name: "Bahri Yanbu", type: "product", flag: "SA", imo: "9379698", berth: "RT-A9", lat: 26.734, lng: 50.279, agent: "Bahri Agency" },
];

let seq = 0;
function jobId() {
  seq += 1;
  return `job_${seq.toString().padStart(2, "0")}`;
}

function refFor(ms: number, n: number) {
  const d = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Riyadh",
    day: "2-digit",
    month: "2-digit",
  }).format(new Date(ms));
  const compact = d.replace("/", "");
  return `RT-${compact}-${n.toString().padStart(2, "0")}`;
}

/** Fixed demo clock so SSR and the client paint the same shift. */
export const DEMO_NOW = Date.parse("2026-08-31T17:34:00+03:00");

export function buildShift(now = DEMO_NOW): OpsSnapshot {
  seq = 0;
  const m = 60_000;
  let n = 0;
  const nextRef = () => {
    n += 1;
    return refFor(now, n);
  };

  const closed = (
    boatId: "yara" | "jenan",
    vesselId: string,
    type: JobType,
    departAgoMin: number,
    cycleMin: number,
    extras: Partial<Job> = {},
  ): Job => {
    const depart = now - (departAgoMin + cycleMin) * m;
    return {
      id: jobId(),
      ref: nextRef(),
      type,
      state: "reported",
      boatId,
      captainId: extras.captainId ?? (boatId === "yara" ? "yusuf" : "jassim"),
      vesselId,
      requestedAt: iso(depart - 50 * m),
      scheduledAt: iso(depart),
      requestedBy: extras.requestedBy ?? "RT ops",
      notes: extras.notes ?? "",
      pax: extras.pax,
      paxOut: extras.paxOut,
      paxReturn: extras.paxReturn,
      cargoPallets: extras.cargoPallets,
      cargoWeightKg: extras.cargoWeightKg,
      timestamps: tripStamps(depart, cycleMin),
      tripCounted: true,
      verifiedAt: iso(depart + cycleMin * m + 8 * m),
      verifyNotes: extras.verifyNotes ?? "Closed. Stamps complete.",
    };
  };

  const jobs: Job[] = [
    closed("yara", "v9", "crew_change", 310, 98, { pax: 7, paxOut: 3, paxReturn: 4, notes: "Inward crew 4 / outward 3" }),
    closed("jenan", "v3", "provisions", 290, 105, { cargoPallets: 12, cargoWeightKg: 840, notes: "Dry stores + bonded" }),
    closed("yara", "v6", "combined", 195, 112, { pax: 5, paxOut: 2, paxReturn: 3, notes: "Crew change + provisions" }),
    closed("jenan", "v5", "personnel", 170, 88, { pax: 3, notes: "Surveyor + agent" }),
    closed("jenan", "v8", "stores", 95, 102, { cargoPallets: 8, cargoWeightKg: 450, notes: "Lube + spares" }),

    {
      id: jobId(),
      ref: nextRef(),
      type: "crew_change",
      state: "executing",
      boatId: "jenan",
      captainId: "jassim",
      vesselId: "v1",
      requestedAt: iso(now - 95 * m),
      scheduledAt: iso(now - 69 * m),
      requestedBy: "Front Queen master",
      notes: "7 inward, 6 outward. Pilot on board 13:00.",
      pax: 13,
      paxOut: 6,
      paxReturn: 7,
      windowStart: iso(now - 55 * m),
      timestamps: {
        departed_base: stampAt(now - 48 * m),
        alongside: stampAt(now - 14 * m),
        ops_start: stampAt(now - 9 * m),
      },
      tripCounted: false,
    },
    {
      id: jobId(),
      ref: nextRef(),
      type: "crew_change",
      state: "dispatched",
      boatId: "yara",
      captainId: "yusuf",
      vesselId: "v6",
      requestedAt: iso(now - 40 * m),
      scheduledAt: iso(now - 19 * m),
      requestedBy: "RT ops",
      notes: "8 pax crew change. Prefer Yara.",
      pax: 8,
      paxOut: 4,
      paxReturn: 4,
      windowStart: iso(now + 10 * m),
      timestamps: {},
      tripCounted: false,
    },
    {
      id: jobId(),
      ref: nextRef(),
      type: "stores",
      state: "requested",
      vesselId: "v2",
      requestedAt: iso(now - 28 * m),
      scheduledAt: iso(now + 56 * m),
      requestedBy: "Maran Antares agent",
      notes: "Spare parts, provisions, tools.",
      cargoPallets: 10,
      cargoWeightKg: 450,
      timestamps: {},
      tripCounted: false,
    },
    {
      id: jobId(),
      ref: nextRef(),
      type: "crew_change",
      state: "planned",
      boatId: "jenan",
      captainId: "nasser",
      vesselId: "v4",
      requestedAt: iso(now - 18 * m),
      scheduledAt: iso(now + 146 * m),
      requestedBy: "Bahri Agency",
      notes: "5 pax after current run.",
      pax: 5,
      paxOut: 2,
      paxReturn: 3,
      timestamps: {},
      tripCounted: false,
    },
    {
      id: jobId(),
      ref: nextRef(),
      type: "documents",
      state: "requested",
      vesselId: "v7",
      requestedAt: iso(now - 12 * m),
      scheduledAt: iso(now + 200 * m),
      requestedBy: "Bahri Agency",
      notes: "Clearance papers + cash to master.",
      timestamps: {},
      tripCounted: false,
    },
  ];

  return {
    vessels: VESSELS,
    jobs,
    online: true,
    role: "shore",
    syncQueue: [],
    seededAt: iso(now),
  };
}

export { BASE_BERTH };
