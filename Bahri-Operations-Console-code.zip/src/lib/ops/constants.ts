import type { Boat, BoatId, Captain, Geo } from "./types";

/** Ras Tanura jetty — Bahri OSV base. */
export const BASE: Geo = { lat: 26.6412, lng: 50.1618 };

export const BASE_BERTH: Record<BoatId, Geo> = {
  yara: { lat: 26.6426, lng: 50.1604 },
  jenan: { lat: 26.6396, lng: 50.1609 },
};

export const BOATS: Boat[] = [
  {
    id: "yara",
    name: "Bahri Yara",
    short: "Yara",
    callsign: "HZ-YARA",
    class: "OSV / crew",
  },
  {
    id: "jenan",
    name: "Bahri Jenan",
    short: "Jenan",
    callsign: "HZ-JENAN",
    class: "OSV / crew",
  },
];

export const CAPTAINS: Captain[] = [
  { id: "yusuf", name: "Yusuf Al-Dossary", boatId: "yara", rank: "Master" },
  { id: "fahad", name: "Fahad Al-Ghamdi", boatId: "yara", rank: "Chief Officer" },
  { id: "jassim", name: "Jassim Al-Otaibi", boatId: "jenan", rank: "Master" },
  { id: "nasser", name: "Nasser Al-Harbi", boatId: "jenan", rank: "Chief Officer" },
];

export const PLOT_BOUNDS = {
  west: 50.08,
  east: 50.42,
  south: 26.52,
  north: 26.78,
};

export const TYPICAL_TRANSIT_MS = 38 * 60 * 1000;
