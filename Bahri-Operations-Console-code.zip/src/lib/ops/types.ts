export type BoatId = "yara" | "jenan";

export type JobType =
  | "crew_change"
  | "provisions"
  | "stores"
  | "combined"
  | "personnel"
  | "garbage"
  | "documents";

export type JobState =
  | "requested"
  | "planned"
  | "dispatched"
  | "tracking"
  | "executing"
  | "verifying"
  | "reported";

export type StampKey =
  | "departed_base"
  | "alongside"
  | "ops_start"
  | "ops_complete"
  | "departed_vessel"
  | "returned_base";

export type BoatStatus = "at_base" | "underway" | "alongside" | "returning";

export type VesselType = "vlcc" | "product" | "lng" | "chemical" | "container" | "bulk";

export type Role = "shore" | BoatId;

export type Geo = { lat: number; lng: number };

export type Stamp = {
  at: string;
  deviceClock: string;
  source: "device";
  pendingSync: boolean;
};

export type Vessel = {
  id: string;
  name: string;
  type: VesselType;
  flag: string;
  imo: string;
  berth: string;
  lat: number;
  lng: number;
  agent: string;
};

export type Boat = {
  id: BoatId;
  name: string;
  short: string;
  callsign: string;
  class: string;
};

export type Captain = {
  id: string;
  name: string;
  boatId: BoatId;
  rank: string;
};

export type Job = {
  id: string;
  ref: string;
  type: JobType;
  state: JobState;
  boatId?: BoatId;
  captainId?: string;
  vesselId: string;
  requestedAt: string;
  scheduledAt?: string;
  requestedBy: string;
  notes: string;
  pax?: number;
  paxOut?: number;
  paxReturn?: number;
  cargoPallets?: number;
  cargoWeightKg?: number;
  windowStart?: string;
  windowEnd?: string;
  timestamps: Partial<Record<StampKey, Stamp>>;
  tripCounted: boolean;
  verifyNotes?: string;
  verifiedAt?: string;
  cancelled?: boolean;
};

export type SyncItem = {
  id: string;
  jobId: string;
  stamp: StampKey;
  at: string;
};

export type OpsSnapshot = {
  vessels: Vessel[];
  jobs: Job[];
  online: boolean;
  role: Role;
  syncQueue: SyncItem[];
  seededAt: string;
};

export type CreateJobInput = {
  vesselId: string;
  type: JobType;
  notes: string;
  pax?: number;
  paxOut?: number;
  paxReturn?: number;
  cargoPallets?: number;
  cargoWeightKg?: number;
  requestedBy: string;
  scheduledAt?: string;
  boatId?: BoatId;
  captainId?: string;
  dispatch?: boolean;
};
