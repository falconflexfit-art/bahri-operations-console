import { create } from "zustand";
import { persist } from "zustand/middleware";
import { BOATS } from "./constants";
import { nextStamp, STAMP_ORDER } from "./format";
import { buildShift } from "./seed";
import type {
  BoatId,
  BoatStatus,
  CreateJobInput,
  Job,
  OpsSnapshot,
  Role,
  Stamp,
  StampKey,
  SyncItem,
} from "./types";

function deviceStamp(now = Date.now()): Stamp {
  const clock = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Riyadh",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).format(new Date(now));
  return {
    at: new Date(now).toISOString(),
    deviceClock: clock,
    source: "device",
    pendingSync: false,
  };
}

function stateAfterStamp(key: StampKey): Job["state"] {
  if (key === "returned_base") return "verifying";
  if (key === "alongside" || key === "ops_start" || key === "ops_complete") return "executing";
  if (key === "departed_vessel") return "tracking";
  return "tracking";
}

export function boatStatus(jobs: Job[], boatId: BoatId): BoatStatus {
  const job = jobs.find(
    (j) => j.boatId === boatId && !j.cancelled && j.state !== "reported" && j.state !== "requested" && j.state !== "planned",
  );
  if (!job) return "at_base";
  const t = job.timestamps;
  if (t.returned_base) return "at_base";
  if (t.departed_vessel) return "returning";
  if (t.alongside) return "alongside";
  if (t.departed_base) return "underway";
  return "at_base";
}

export function activeJobFor(jobs: Job[], boatId: BoatId) {
  return (
    jobs.find(
      (j) =>
        j.boatId === boatId &&
        !j.cancelled &&
        (j.state === "dispatched" || j.state === "tracking" || j.state === "executing"),
    ) ?? null
  );
}

export function tripsToday(jobs: Job[], boatId?: BoatId) {
  return jobs.filter((j) => j.tripCounted && !j.cancelled && (boatId ? j.boatId === boatId : true)).length;
}

let jobSeq = 40;
function newId() {
  jobSeq += 1;
  return `job_${jobSeq}`;
}

function nextRef(jobs: Job[]) {
  const n = jobs.length + 1;
  const d = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Riyadh",
    day: "2-digit",
    month: "2-digit",
  }).format(new Date());
  return `RT-${d.replace("/", "")}-${n.toString().padStart(2, "0")}`;
}

type OpsStore = OpsSnapshot & {
  setRole: (role: Role) => void;
  setOnline: (online: boolean) => void;
  createRequest: (input: CreateJobInput) => string;
  planJob: (id: string, boatId: BoatId, captainId?: string) => void;
  dispatchJob: (id: string) => void;
  assignAndDispatch: (id: string, boatId: BoatId, captainId?: string) => void;
  stamp: (jobId: string, key?: StampKey) => { ok: boolean; message: string; stamp?: StampKey };
  verifyJob: (id: string, notes: string) => void;
  cancelJob: (id: string) => void;
  flushSync: () => void;
  resetShift: () => void;
};

export const useOps = create<OpsStore>()(
  persist(
    (set, get) => ({
      ...buildShift(),
      setRole: (role) => set({ role }),
      setOnline: (online) => {
        set({ online });
        if (online) get().flushSync();
      },
      createRequest: (input) => {
        const id = newId();
        const pax =
          input.pax ??
          (input.paxOut != null || input.paxReturn != null
            ? (input.paxOut ?? 0) + (input.paxReturn ?? 0)
            : undefined);
        let state: Job["state"] = "requested";
        if (input.dispatch && input.boatId) state = "dispatched";
        else if (input.boatId) state = "planned";
        const notes =
          input.notes ||
          [
            input.cargoPallets ? `${input.cargoPallets} pallets` : "",
            input.cargoWeightKg ? `${input.cargoWeightKg} kg` : "",
          ]
            .filter(Boolean)
            .join(" · ");
        const job: Job = {
          id,
          ref: nextRef(get().jobs),
          type: input.type,
          state,
          vesselId: input.vesselId,
          requestedAt: new Date().toISOString(),
          scheduledAt: input.scheduledAt,
          requestedBy: input.requestedBy,
          notes,
          pax,
          paxOut: input.paxOut,
          paxReturn: input.paxReturn,
          cargoPallets: input.cargoPallets,
          cargoWeightKg: input.cargoWeightKg,
          boatId: input.boatId,
          captainId: input.captainId,
          timestamps: {},
          tripCounted: false,
        };
        set({ jobs: [job, ...get().jobs] });
        return id;
      },
      planJob: (id, boatId, captainId) => {
        set({
          jobs: get().jobs.map((j) =>
            j.id === id && (j.state === "requested" || j.state === "planned")
              ? { ...j, boatId, captainId: captainId ?? j.captainId, state: "planned" }
              : j,
          ),
        });
      },
      dispatchJob: (id) => {
        set({
          jobs: get().jobs.map((j) =>
            j.id === id && j.boatId && (j.state === "planned" || j.state === "requested")
              ? { ...j, state: "dispatched" }
              : j,
          ),
        });
      },
      assignAndDispatch: (id, boatId, captainId) => {
        set({
          jobs: get().jobs.map((j) =>
            j.id === id && (j.state === "requested" || j.state === "planned")
              ? { ...j, boatId, captainId: captainId ?? j.captainId, state: "dispatched" }
              : j,
          ),
        });
      },
      stamp: (jobId, key) => {
        const job = get().jobs.find((j) => j.id === jobId);
        if (!job) return { ok: false, message: "Job not found" };
        if (job.cancelled) return { ok: false, message: "Job cancelled" };
        if (!job.boatId) return { ok: false, message: "No boat assigned" };
        const role = get().role;
        if (role !== "shore" && role !== job.boatId) {
          return { ok: false, message: `Only ${BOATS.find((b) => b.id === job.boatId)?.name} can stamp this trip` };
        }
        if (job.state === "requested" || job.state === "planned") {
          return { ok: false, message: "Job is not dispatched" };
        }
        const next = nextStamp(job.timestamps);
        const useKey = key ?? next;
        if (!useKey) return { ok: false, message: "All six stamps are already in" };
        if (useKey !== next) return { ok: false, message: `Next stamp is ${next}` };
        const online = get().online;
        const stamp = { ...deviceStamp(), pendingSync: !online };
        const timestamps = { ...job.timestamps, [useKey]: stamp };
        const counted = useKey === "returned_base" ? true : job.tripCounted;
        const nextState = stateAfterStamp(useKey);
        set({
          jobs: get().jobs.map((j) =>
            j.id === jobId
              ? { ...j, timestamps, state: nextState, tripCounted: counted }
              : j,
          ),
        });
        if (!online) {
          const item: SyncItem = { id: `${jobId}-${useKey}`, jobId, stamp: useKey, at: stamp.at };
          set({ syncQueue: [...get().syncQueue, item] });
        }
        return { ok: true, message: `${useKey} recorded`, stamp: useKey };
      },
      verifyJob: (id, notes) => {
        const job = get().jobs.find((j) => j.id === id);
        if (!job) return;
        const complete = STAMP_ORDER.every((k) => job.timestamps[k]);
        if (!complete) return;
        set({
          jobs: get().jobs.map((j) =>
            j.id === id
              ? {
                  ...j,
                  state: "reported",
                  tripCounted: true,
                  verifyNotes: notes,
                  verifiedAt: new Date().toISOString(),
                }
              : j,
          ),
        });
      },
      cancelJob: (id) => {
        set({
          jobs: get().jobs.map((j) =>
            j.id === id && (j.state === "requested" || j.state === "planned")
              ? { ...j, cancelled: true, state: "reported" }
              : j,
          ),
        });
      },
      flushSync: () => {
        const q = get().syncQueue;
        if (q.length === 0) return;
        set({
          jobs: get().jobs.map((j) => {
            const related = q.filter((s) => s.jobId === j.id);
            if (related.length === 0) return j;
            const timestamps = { ...j.timestamps };
            for (const s of related) {
              const t = timestamps[s.stamp];
              if (t) timestamps[s.stamp] = { ...t, pendingSync: false };
            }
            return { ...j, timestamps };
          }),
          syncQueue: [],
        });
      },
      resetShift: () => {
        const snap = buildShift();
        set({ ...snap });
      },
    }),
    {
      name: "bahri-ops-console-v1",
      skipHydration: true,
      partialize: (s) => ({
        vessels: s.vessels,
        jobs: s.jobs,
        online: s.online,
        role: s.role,
        syncQueue: s.syncQueue,
        seededAt: s.seededAt,
      }),
    },
  ),
);

export { BOATS };
