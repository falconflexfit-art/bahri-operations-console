import { BASE_BERTH, PLOT_BOUNDS, TYPICAL_TRANSIT_MS } from "./constants";
import type { BoatId, Geo, Job, Vessel } from "./types";

export function project(lat: number, lng: number, w: number, h: number) {
  const { west, east, south, north } = PLOT_BOUNDS;
  return {
    x: ((lng - west) / (east - west)) * w,
    y: ((north - lat) / (north - south)) * h,
  };
}

function lerp(a: Geo, b: Geo, t: number): Geo {
  const u = Math.min(1, Math.max(0, t));
  return { lat: a.lat + (b.lat - a.lat) * u, lng: a.lng + (b.lng - a.lng) * u };
}

function heading(from: Geo, to: Geo) {
  const dy = to.lat - from.lat;
  const dx = (to.lng - from.lng) * Math.cos(((from.lat + to.lat) / 2) * (Math.PI / 180));
  return (Math.atan2(dx, dy) * 180) / Math.PI;
}

export function boatPose(
  boatId: BoatId,
  job: Job | null,
  vessel: Vessel | undefined,
  now: number,
): Geo & { heading: number } {
  const home = BASE_BERTH[boatId];
  if (!job || !vessel) return { ...home, heading: 78 };

  const t = job.timestamps;
  if (t.returned_base) return { ...home, heading: 78 };
  if (t.alongside && !t.departed_vessel) {
    return { lat: vessel.lat, lng: vessel.lng, heading: heading(home, vessel) };
  }
  if (t.departed_base && !t.alongside) {
    const start = new Date(t.departed_base.at).getTime();
    const p = now ? Math.min(0.97, Math.max(0.05, (now - start) / TYPICAL_TRANSIT_MS)) : 0.55;
    const pos = lerp(home, vessel, p);
    return { ...pos, heading: heading(home, vessel) };
  }
  if (t.departed_vessel && !t.returned_base) {
    const start = new Date(t.departed_vessel.at).getTime();
    const p = now ? Math.min(0.97, Math.max(0.05, (now - start) / TYPICAL_TRANSIT_MS)) : 0.45;
    const pos = lerp({ lat: vessel.lat, lng: vessel.lng }, home, p);
    return { ...pos, heading: heading(vessel, home) };
  }
  return { ...home, heading: heading(home, vessel) };
}
