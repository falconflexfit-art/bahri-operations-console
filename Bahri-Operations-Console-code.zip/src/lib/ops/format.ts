import type { BoatId, BoatStatus, Job, JobState, JobType, StampKey, VesselType } from "./types";

export const TZ = "Asia/Riyadh";

export const PIPELINE: { state: JobState; label: string }[] = [
  { state: "requested", label: "Request" },
  { state: "planned", label: "Plan" },
  { state: "dispatched", label: "Dispatch" },
  { state: "tracking", label: "Track" },
  { state: "executing", label: "Execute" },
  { state: "verifying", label: "Verify" },
  { state: "reported", label: "Report" },
];

export const STAMP_ORDER: StampKey[] = [
  "departed_base",
  "alongside",
  "ops_start",
  "ops_complete",
  "departed_vessel",
  "returned_base",
];

export const STAMP_LABEL: Record<StampKey, string> = {
  departed_base: "Departed base",
  alongside: "Alongside vessel",
  ops_start: "Ops start",
  ops_complete: "Ops complete",
  departed_vessel: "Departed vessel",
  returned_base: "Returned base",
};

export const STAMP_HINT: Record<StampKey, string> = {
  departed_base: "Left Ras Tanura jetty",
  alongside: "Made fast to client vessel",
  ops_start: "Transfer / work began",
  ops_complete: "Transfer / work finished",
  departed_vessel: "Cast off client vessel",
  returned_base: "Back at Ras Tanura",
};

export const JOB_TYPE_LABEL: Record<JobType, string> = {
  crew_change: "Crew change",
  provisions: "Provisions",
  stores: "Stores delivery",
  combined: "Combined",
  personnel: "Personnel",
  garbage: "Garbage",
  documents: "Documents",
};

export const VESSEL_TYPE_LABEL: Record<VesselType, string> = {
  vlcc: "VLCC",
  product: "Product",
  lng: "LNG",
  chemical: "Chemical",
  container: "Container",
  bulk: "Bulk",
};

export const BOAT_STATUS_LABEL: Record<BoatStatus, string> = {
  at_base: "Available",
  underway: "Underway",
  alongside: "Alongside",
  returning: "Returning",
};

export type BoardStatus = "Draft" | "Assigned" | "Underway" | "Returned" | "Completed" | "Cancelled";
export type BoardTone = "muted" | "steel" | "ok" | "warn" | "danger";

export function boardStatus(job: Job): { label: BoardStatus; tone: BoardTone } {
  if (job.cancelled) return { label: "Cancelled", tone: "muted" };
  if (job.state === "reported") return { label: "Completed", tone: "ok" };
  if (job.state === "verifying") return { label: "Returned", tone: "warn" };
  if (job.state === "executing" || job.state === "tracking") return { label: "Underway", tone: "steel" };
  if (job.state === "dispatched") {
    return job.timestamps.departed_base
      ? { label: "Underway", tone: "steel" }
      : { label: "Assigned", tone: "ok" };
  }
  if (job.state === "planned") return { label: "Assigned", tone: "ok" };
  return { label: "Draft", tone: "muted" };
}

export function formatClock(iso: string | number | Date, withSeconds = false) {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: TZ,
    hour: "2-digit",
    minute: "2-digit",
    second: withSeconds ? "2-digit" : undefined,
    hour12: false,
  }).format(new Date(iso));
}

export function formatDate(iso: string | number | Date) {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: TZ,
    weekday: "short",
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(new Date(iso));
}

export function formatDateShort(iso: string | number | Date) {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: TZ,
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(new Date(iso));
}

export function formatDeviceNow(now = Date.now()) {
  return formatClock(now, true);
}

export function minutesBetween(a: string, b: string) {
  return Math.max(0, Math.round((new Date(b).getTime() - new Date(a).getTime()) / 60000));
}

export function formatDuration(mins: number) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h <= 0) return `${m}m`;
  return `${h}h ${m.toString().padStart(2, "0")}m`;
}

export function cycleMinutes(job: { timestamps: Partial<Record<StampKey, { at: string }>> }) {
  const start = job.timestamps.departed_base?.at;
  const end = job.timestamps.returned_base?.at;
  if (!start || !end) return null;
  return minutesBetween(start, end);
}

export function boatName(id: BoatId) {
  return id === "yara" ? "Bahri Yara" : "Bahri Jenan";
}

export function nextStamp(stamps: Partial<Record<StampKey, unknown>>): StampKey | null {
  for (const key of STAMP_ORDER) {
    if (!stamps[key]) return key;
  }
  return null;
}

export function stateIndex(state: JobState) {
  return PIPELINE.findIndex((p) => p.state === state);
}

export function jobWhen(job: Job) {
  return job.scheduledAt ?? job.windowStart ?? job.requestedAt;
}
